using System;

class Program
{
    static void Main()
    {
        // Variáveis principais do jogo
        string nomeJogador;
        int energia = 3;
        int pontos = 0;
        int fase = 1;
        int erros = 0;
        bool sair = false;

        // Introdução
        Console.WriteLine("========================================");
        Console.WriteLine("       ESCAPE DO LABORATORIO");
        Console.WriteLine("========================================");
        Console.WriteLine("Voce dormiu no laboratorio de informatica da faculdade.");
        Console.WriteLine("Quando acordou, percebeu que ficou preso.");
        Console.WriteLine("Para escapar, voce precisa passar por 3 fases.");
        Console.WriteLine("Cada erro tira energia. Cada acerto da pontos.");
        Console.WriteLine();

        // Nome do jogador
        Console.Write("Digite o nome do jogador: ");
        nomeJogador = Console.ReadLine();

        Console.WriteLine();
        Console.WriteLine("Boa sorte, " + nomeJogador + "!");
        Console.WriteLine("Energia inicial: " + energia);
        Console.WriteLine("Pontos iniciais: " + pontos);
        Console.WriteLine();
        Console.WriteLine("Pressione uma tecla para continuar...");
        Console.ReadKey();

        // Escolha inicial
        Console.Clear();
        Console.WriteLine("========================================");
        Console.WriteLine("       ESCAPE DO LABORATORIO");
        Console.WriteLine("========================================");
        Console.WriteLine("Jogador: " + nomeJogador);
        Console.WriteLine();
        Console.WriteLine("O que voce deseja fazer?");
        Console.WriteLine("1 - Tentar escapar do laboratorio");
        Console.WriteLine("2 - Esperar alguem abrir a porta");
        Console.Write("Escolha uma opcao: ");
        string escolhaInicial = Console.ReadLine();

        if (escolhaInicial == "2")
        {
            sair = true;
            Console.Clear();
            Console.WriteLine("========================================");
            Console.WriteLine("DECISAO DO JOGADOR");
            Console.WriteLine("========================================");
            Console.WriteLine("Voce decidiu esperar. Alguem abriu a porta depois de um tempo.");
            Console.WriteLine();
        }
        else if (escolhaInicial == "1")
        {
            Console.Clear();
            Console.WriteLine("Voce decidiu tentar escapar. Boa sorte!");
            Console.WriteLine("Pressione uma tecla para iniciar...");
            Console.ReadKey();
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Opcao invalida. Continuando como se fosse tentar escapar...");
            Console.WriteLine("Pressione uma tecla para iniciar...");
            Console.ReadKey();
        }

        // Loop principal do jogo
        while (energia > 0 && fase <= 3 && sair == false)
        {
            Console.Clear();

            // Barra de energia com simbolo
            string barraEnergia = "";
            for (int i = 0; i < energia; i++)
                barraEnergia = barraEnergia + "[*] ";

            // Painel visível do jogo
            Console.WriteLine("========================================");
            Console.WriteLine("           PAINEL DO JOGO");
            Console.WriteLine("========================================");
            Console.WriteLine("Jogador      : " + nomeJogador);
            Console.WriteLine("Fase atual   : " + fase);
            Console.WriteLine("Energia      : " + barraEnergia);
            Console.WriteLine("Pontos       : " + pontos);
            Console.WriteLine("========================================");
            Console.WriteLine();

            // FASE 1
            if (fase == 1)
            {
                Console.WriteLine("FASE 1 - ACESSO AO COMPUTADOR");
                Console.WriteLine("Para abrir o sistema, responda a pergunta:");
                Console.WriteLine("Quanto e 8 + 4?");
                Console.Write("Resposta: ");
                string resposta1 = Console.ReadLine();

                if (resposta1.Trim() == "12")
                {
                    pontos = pontos + 10;
                    fase = fase + 1;

                    Console.WriteLine();
                    Console.WriteLine("Correto! O computador foi desbloqueado.");
                    Console.WriteLine("Voce ganhou 10 pontos.");
                    Console.WriteLine("Pressione uma tecla para avancar para a proxima fase...");
                    Console.ReadKey();
                }
                else
                {
                    energia = energia - 1;
                    erros = erros + 1;

                    Console.WriteLine();
                    Console.WriteLine("Errado! Voce perdeu 1 ponto de energia.");
                    Console.WriteLine("Pressione uma tecla para continuar...");
                    Console.ReadKey();
                }
            }
            // FASE 2
            else if (fase == 2)
            {
                Console.WriteLine("FASE 2 - ENCONTRANDO A CHAVE DO ARMARIO");
                Console.WriteLine("Voce encontrou uma pista com logica.");
                Console.WriteLine("Qual estrutura de repeticao foi exigida no trabalho?");
                Console.WriteLine("1 - for");
                Console.WriteLine("2 - while");
                Console.WriteLine("3 - foreach");
                Console.Write("Digite o numero da alternativa: ");
                string resposta2 = Console.ReadLine();

                if (resposta2.Trim() == "2")
                {
                    pontos = pontos + 10;
                    fase = fase + 1;

                    Console.WriteLine();
                    Console.WriteLine("Correto! Voce encontrou a chave do armario.");
                    Console.WriteLine("Voce ganhou 10 pontos.");
                    Console.WriteLine("Pressione uma tecla para avancar para a proxima fase...");
                    Console.ReadKey();
                }
                else
                {
                    energia = energia - 1;
                    erros = erros + 1;

                    Console.WriteLine();
                    Console.WriteLine("Errado! Voce perdeu 1 ponto de energia.");
                    Console.WriteLine("Pressione uma tecla para continuar...");
                    Console.ReadKey();
                }
            }
            // FASE 3
            else if (fase == 3)
            {
                Console.WriteLine("FASE 3 - ABRINDO A PORTA DE SAIDA");
                Console.WriteLine("Ultimo desafio.");
                Console.WriteLine("Em C#, qual simbolo usamos para comparar se dois valores sao iguais?");
                Console.WriteLine("1 - =");
                Console.WriteLine("2 - ==");
                Console.WriteLine("3 - !=");
                Console.Write("Digite o numero da alternativa: ");
                string resposta3 = Console.ReadLine();

                if (resposta3.Trim() == "2")
                {
                    pontos = pontos + 10;
                    fase = fase + 1;

                    Console.WriteLine();
                    Console.WriteLine("Correto! A porta foi aberta.");
                    Console.WriteLine("Voce ganhou 10 pontos.");
                    Console.WriteLine("Pressione uma tecla para ver o resultado final...");
                    Console.ReadKey();
                }
                else
                {
                    energia = energia - 1;
                    erros = erros + 1;

                    Console.WriteLine();
                    Console.WriteLine("Errado! Voce perdeu 1 ponto de energia.");
                    Console.WriteLine("Pressione uma tecla para continuar...");
                    Console.ReadKey();
                }
            }

            // Verifica se perdeu
            if (energia <= 0)
            {
                Console.Clear();
                Console.WriteLine("========================================");
                Console.WriteLine("            FIM DE JOGO");
                Console.WriteLine("========================================");
                Console.WriteLine("Sua energia acabou. Voce perdeu o jogo.");
                Console.WriteLine();
            }
            // Se ainda nao terminou, pergunta se deseja continuar
            else if (fase <= 3)
            {
                Console.Clear();
                Console.WriteLine("========================================");
                Console.WriteLine("           STATUS ATUAL");
                Console.WriteLine("========================================");
                Console.WriteLine("Jogador      : " + nomeJogador);
                Console.WriteLine("Fase atual   : " + fase);
                Console.WriteLine("Energia      : " + barraEnergia);
                Console.WriteLine("Pontos       : " + pontos);
                Console.WriteLine("========================================");
                Console.WriteLine();

                Console.Write("Deseja continuar jogando? (s para continuar / n para sair): ");
                string continuar = Console.ReadLine();

                if (continuar == "n" || continuar == "N")
                {
                    sair = true;
                }
            }
        }

        // Resultado final
        Console.Clear();
        Console.WriteLine("========================================");
        Console.WriteLine("           RESULTADO FINAL");
        Console.WriteLine("========================================");
        Console.WriteLine("Jogador        : " + nomeJogador);

        if (fase > 3)
            Console.WriteLine("Fase final     : 3 (completa!)");
        else
            Console.WriteLine("Fase final     : " + fase);

        Console.WriteLine("Energia final  : " + energia);
        Console.WriteLine("Pontos finais  : " + pontos);
        Console.WriteLine("Erros cometidos: " + erros);
        Console.WriteLine("========================================");

        if (fase > 3 && energia > 0)
        {
            Console.WriteLine("Parabens! Voce venceu e escapou do laboratorio!");

            if (pontos == 30)
                Console.WriteLine("Pontuacao perfeita! Voce nao errou nada!");
            else if (pontos >= 20)
                Console.WriteLine("Muito bem! Voce quase zerou sem erros.");
            else
                Console.WriteLine("Continue praticando!");
        }
        else if (energia <= 0)
        {
            Console.WriteLine("Fim de jogo! Voce nao conseguiu escapar.");
        }
        else if (sair == true)
        {
            Console.WriteLine("Voce desistiu e decidiu esperar alguem abrir o laboratorio.");
        }

        Console.WriteLine();
        Console.WriteLine("Pressione qualquer tecla para encerrar...");
        Console.ReadKey();
    }
}
